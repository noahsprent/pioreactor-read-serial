# If implementing an automation: Import the Class of your automation file:
# from <SUBFOLDER CONTAINING PLUGIN>.<PYTHON FILE NAME> import <CLASS NAME>
# If implementing a job: This will contain an import statement such as the following:
from pioreactor_read_serial.pioreactor_read_serial import click_pioreactor_read_serial
